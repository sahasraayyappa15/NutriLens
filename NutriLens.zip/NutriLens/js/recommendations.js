(() => {
  const preferredSwaps = {
    "potato-chips": ["roasted-makhana", "air-popped-popcorn", "roasted-chana"],
    "banana-chips": ["air-popped-popcorn", "roasted-makhana", "roasted-chana"],
    "mixture": ["roasted-chana", "masala-makhana", "air-popped-popcorn"],
    "namkeen": ["roasted-makhana", "roasted-chana", "khakhra"],
    "cola": ["sparkling-water", "coconut-water", "unsweetened-lassi"],
    "milk-chocolate": ["dark-chocolate", "dates", "strawberries"],
    "cream-cookies": ["strawberries", "fruit-cup", "dates"]
  };

  function recommendSnacks(snackId, count) {
    const allSnacks = window.NUTRILENS_SNACKS || [];
    const original = allSnacks.find((snack) => snack.id === snackId);
    if (!original) return [];
    const preferred = preferredSwaps[snackId] || [];
    const ranked = preferred
      .map((id) => allSnacks.find((snack) => snack.id === id))
      .filter(Boolean);
    const more = allSnacks.filter((snack) =>
      snack.id !== original.id &&
      snack.healthy &&
      snack.category === original.category &&
      !ranked.some((item) => item.id === snack.id)
    );
    return [...ranked, ...more].slice(0, count || 3);
  }

  window.NutriLensRecommendations = { recommendSnacks };
})();

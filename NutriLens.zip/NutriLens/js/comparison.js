(() => {
  const root = document.getElementById("comparison-view");
  if (!root) return;

  const snacks = window.NUTRILENS_SNACKS || [];
  const params = new URLSearchParams(location.search);
  const original = snacks.find((snack) => snack.id === params.get("from")) || snacks.find((snack) => snack.id === "potato-chips");
  const alternatives = window.NutriLensRecommendations.recommendSnacks(original.id, 3);
  let alternative = snacks.find((snack) => snack.id === params.get("to")) || alternatives[0] || snacks.find((snack) => snack.id === "roasted-makhana");
  let radarChart;

  function reductionPercent(before, after) {
    return before > 0 ? Math.max(0, Math.round((before - after) / before * 100)) : 0;
  }

  function safeSaved(before, after) {
    return Math.max(0, before - after);
  }

  function render() {
    const old = original.perServing;
    const better = alternative.perServing;
    const calorieSaved = safeSaved(old.calories, better.calories);
    const satReduction = reductionPercent(old.saturatedFat, better.saturatedFat);
    const sugarSaved = safeSaved(old.sugar, better.sugar);
    const sodiumSaved = safeSaved(old.sodium, better.sodium);
    const proteinGain = Math.max(0, better.protein - old.protein);
    const fiberGain = Math.max(0, better.fiber - old.fiber);
    const choices = alternatives.some((item) => item.id === alternative.id) ? alternatives : [alternative, ...alternatives].slice(0, 4);

    root.innerHTML = `<div class="comparison-hero"><div><a class="back-link" href="nutrition.html?id=${encodeURIComponent(original.id)}"><i class="bi bi-arrow-left"></i> Back to snack details</a><span class="eyebrow eyebrow-dark">THE SMARTER-SNACK SHOWDOWN</span><h1>Same craving.<br><em>A brighter choice.</em></h1><p>A side-by-side look at the sample nutrition per serving.</p></div><div><label class="period-pill alternative-picker"><span>Try another swap</span><select id="alternative-choice" aria-label="Choose a snack alternative">${choices.map((item) => `<option value="${item.id}" ${item.id === alternative.id ? "selected" : ""}>${item.name}</option>`).join("")}</select></label></div></div>
    <div class="comparison-pair"><article class="compare-food-card"><img src="${original.image}" alt="${original.name}"><div><span class="eyebrow eyebrow-dark">YOUR USUAL</span><h3>${original.name}</h3><p>Grade ${original.grade} · ${original.servingSize} ${original.servingUnit}</p><div class="food-kcal">${old.calories}<small> kcal</small></div></div></article><div class="compare-vs">VS</div><article class="compare-food-card"><img src="${alternative.image}" alt="${alternative.name}"><div><span class="eyebrow eyebrow-dark">A FRESH FIND</span><h3>${alternative.name}</h3><p>Grade ${alternative.grade} · ${alternative.servingSize} ${alternative.servingUnit}</p><div class="food-kcal">${better.calories}<small> kcal</small></div></div></article></div>
    <section class="swap-savings-banner"><div class="saving-intro"><span class="eyebrow">THE GOOD STUFF</span><strong>One swap can add up.</strong></div><div class="saving-metric"><strong>${calorieSaved}</strong><small>calories saved</small></div><div class="saving-metric"><strong>${satReduction}%</strong><small>less saturated fat</small></div><div class="saving-metric"><strong>${sugarSaved}g</strong><small>less sugar · ${sodiumSaved}mg less sodium</small></div></section>
    <div class="compare-content-grid"><section class="panel"><div class="panel-heading"><div><span class="eyebrow eyebrow-dark">NUTRIENTS AT A GLANCE</span><h2>What changes in a serving?</h2></div></div><div class="nutrition-bars">${barRow("Calories", old.calories, better.calories, "kcal")}${barRow("Sat. fat", old.saturatedFat, better.saturatedFat, "g")}${barRow("Sugar", old.sugar, better.sugar, "g")}${barRow("Sodium", old.sodium, better.sodium, "mg")}${barRow("Protein", old.protein, better.protein, "g")}${barRow("Fibre", old.fiber, better.fiber, "g")}</div><div class="chart-key"><span><i class="old-key"></i> ${original.name}</span><span><i class="new-key"></i> ${alternative.name}</span></div></section>
    <section class="panel"><div class="panel-heading"><div><span class="eyebrow eyebrow-dark">THE WHOLE PICTURE</span><h2>Nutrition balance</h2></div></div><div class="radar-wrap"><canvas id="nutrition-radar" aria-label="Radar chart comparing the snack nutrition balance"></canvas></div><small class="chart-note">Relative balance for this comparison. Demo values, not a medical assessment.</small></section></div>
    <section class="nutrition-improvements"><h3>A few feel-good differences</h3><div class="improvement-list"><div class="improvement-item"><i class="bi bi-lightning-charge"></i><span><strong>${calorieSaved} fewer</strong> calories</span></div><div class="improvement-item"><i class="bi bi-droplet"></i><span><strong>${satReduction}% less</strong> saturated fat</span></div><div class="improvement-item"><i class="bi bi-egg"></i><span><strong>+${formatNumber(proteinGain)}g</strong> protein</span></div><div class="improvement-item"><i class="bi bi-flower1"></i><span><strong>+${formatNumber(fiberGain)}g</strong> fibre</span></div><div class="improvement-item"><i class="bi bi-cup-straw"></i><span><strong>${sugarSaved}g less</strong> sugar</span></div><div class="improvement-item"><i class="bi bi-heart-pulse"></i><span><strong>${sodiumSaved}mg less</strong> sodium</span></div></div></section>
    <section class="exercise-equivalency"><div><span class="eyebrow eyebrow-dark">JUST FOR PERSPECTIVE</span><h2>Calories in everyday movement.</h2><p>Very rough estimates for a 70 kg adult—actual energy use varies by person and pace.</p></div><div class="exercise-options">${exerciseTile("bi-person-walking", "Walking", calorieSaved, 4)}${exerciseTile("bi-person-running", "Jogging", calorieSaved, 10)}${exerciseTile("bi-bicycle", "Cycling", calorieSaved, 8)}</div></section>
    <div class="swap-action-row"><div><span class="eyebrow eyebrow-dark">READY WHEN YOU ARE</span><p>Log this small win and keep your progress moving.</p></div><button id="confirm-swap" class="btn btn-forest"><i class="bi bi-check2-circle"></i> I Swapped This!</button></div>`;

    root.querySelector("#alternative-choice").addEventListener("change", (event) => {
      const selected = snacks.find((snack) => snack.id === event.target.value);
      if (!selected) return;
      alternative = selected;
      params.set("from", original.id);
      params.set("to", alternative.id);
      history.replaceState(null, "", `${location.pathname}?${params.toString()}`);
      render();
    });
    root.querySelector("#confirm-swap").addEventListener("click", logSwap);
    animateBars();
    drawRadar();
  }

  function barRow(label, before, after, unit) {
    const limit = Math.max(before, after, 1);
    const beforeWidth = Math.max(2, before / limit * 100);
    const afterWidth = Math.max(2, after / limit * 100);
    return `<div class="nutrition-bar-row"><span>${label}</span><div class="nutrition-bar-stack"><div class="bar-track"><div class="bar-fill old" data-width="${beforeWidth}"></div></div><div class="bar-track"><div class="bar-fill new" data-width="${afterWidth}"></div></div></div><div class="bar-values">${formatNumber(before)}<br>${formatNumber(after)} ${unit}</div></div>`;
  }

  function animateBars() {
    requestAnimationFrame(() => root.querySelectorAll(".bar-fill").forEach((bar) => {
      bar.style.width = `${bar.dataset.width}%`;
    }));
  }

  function drawRadar() {
    const canvas = root.querySelector("#nutrition-radar");
    if (!canvas || !window.Chart) return;
    if (radarChart) radarChart.destroy();
    const facts = ["calories", "saturatedFat", "sugar", "sodium", "protein", "fiber"];
    const higherIsBetter = new Set(["protein", "fiber"]);
    const maxFor = (key) => Math.max(original.perServing[key], alternative.perServing[key], 1);
    const score = (snack, key) => {
      const ratio = snack.perServing[key] / maxFor(key);
      return Math.round((higherIsBetter.has(key) ? ratio : 1 - ratio) * 100);
    };
    radarChart = new Chart(canvas, {
      type: "radar",
      data: {
        labels: ["Calories", "Sat. fat", "Sugar", "Sodium", "Protein", "Fibre"],
        datasets: [
          { label: original.name, data: facts.map((key) => score(original, key)), borderColor: "#B9A49A", backgroundColor: "#B9A49A45", pointBackgroundColor: "#B9A49A", borderWidth: 2 },
          { label: alternative.name, data: facts.map((key) => score(alternative, key)), borderColor: "#762F45", backgroundColor: "#762F4545", pointBackgroundColor: "#762F45", borderWidth: 2 }
        ]
      },
      options: { maintainAspectRatio: false, scales: { r: { min: 0, max: 100, ticks: { display: false, stepSize: 25 }, pointLabels: { color: "#B9A49A", font: { size: 9 } }, grid: { color: "#EDE5DF" }, angleLines: { color: "#EDE5DF" } } }, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (context) => `${context.dataset.label}: ${context.raw}% relative score` } } } }
    });
  }

  function formatNumber(value) {
    return Number.isInteger(value) ? String(value) : Number(value.toFixed(1)).toString();
  }

  function exerciseTile(icon, activity, calories, caloriesPerMinute) {
    const minutes = calories ? Math.max(1, Math.round(calories / caloriesPerMinute)) : 0;
    return `<article class="exercise-tile"><span class="exercise-icon"><i class="bi ${icon}"></i></span><strong>${minutes} min</strong><small>${activity}</small></article>`;
  }

  function logSwap(event) {
    const button = event.currentTarget;
    if (button.disabled) return;
    window.NutriLensTracker.saveSwap(original, alternative);
    button.disabled = true;
    button.innerHTML = '<i class="bi bi-check-circle-fill"></i> Swap logged!';
    const toastElement = document.getElementById("swap-toast");
    if (toastElement && window.bootstrap) bootstrap.Toast.getOrCreateInstance(toastElement, { delay: 5000 }).show();
  }

  render();
})();

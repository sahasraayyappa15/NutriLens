(() => {
  const navItems = [
    ["Explore", "explore.html", ["explore", "nutrition", "compare"]],
    ["Dashboard", "dashboard.html", ["dashboard"]],
    ["My swaps", "progress.html", ["progress"]],
    ["Challenges", "challenges.html", ["challenges"]]
  ];
  const moreItems = [
    ["Hostel hacks", "hostel-hacks.html", "hostel"],
    ["Sugar cubes", "sugar.html", "sugar"],
    ["Barcode scanner", "scanner.html", "scanner"]
  ];
  const page = document.body.dataset.page;
  const header = document.getElementById("site-header");
  const footer = document.getElementById("site-footer");

  if (header) renderHeader();
  if (footer) renderFooter();
  if (window.AOS) AOS.init({ duration: 650, once: true, offset: 55 });

  initializeHome();
  initializeDashboard();
  initializeProgress();
  initializeChallenges();
  initializeHostelHacks();
  initializeSugar();
  initializeScanner();

  function renderHeader() {
    const nav = navItems.map(([label, href, pages]) =>
      `<a class="${pages.includes(page) ? "active" : ""}" href="${href}">${label}</a>`
    ).join("");
    const more = moreItems.map(([label, href, key]) =>
      `<a class="${key === page ? "active" : ""}" href="${href}">${label}</a>`
    ).join("");
    const mobile = [...navItems.map(([label, href]) => [label, href]), ...moreItems.map(([label, href]) => [label, href])]
      .map(([label, href]) => `<a href="${href}">${label}</a>`).join("");
    header.innerHTML = `<header class="site-header"><div class="container nav-shell">
      <a class="brand" href="index.html" aria-label="NutriLens home"><span class="brand-mark">N</span>nutri<span class="brand-dot">lens</span></a>
      <nav class="main-nav" aria-label="Main navigation">${nav}<div class="nav-more"><button type="button" class="${moreItems.some((item) => item[2] === page) ? "active" : ""}" aria-expanded="false">More <i class="bi bi-chevron-down"></i></button><div class="nav-dropdown">${more}</div></div></nav>
      <div class="nav-actions"><a class="nav-dashboard" href="dashboard.html">My progress <i class="bi bi-arrow-up-right"></i></a><a class="btn btn-forest nav-cta" href="explore.html">Find a snack</a></div>
      <button class="nav-toggle" type="button" aria-label="Open navigation" aria-expanded="false"><i class="bi bi-list"></i></button>
    </div><nav class="mobile-menu" aria-label="Mobile navigation">${mobile}</nav></header>`;
    const toggle = header.querySelector(".nav-toggle");
    const mobileMenu = header.querySelector(".mobile-menu");
    toggle.addEventListener("click", (event) => {
      event.stopPropagation();
      const open = toggle.getAttribute("aria-expanded") !== "true";
      mobileMenu.classList.toggle("open", open);
      toggle.setAttribute("aria-expanded", String(open));
      toggle.innerHTML = `<i class="bi bi-${open ? "x-lg" : "list"}"></i>`;
    });
    const moreButton = header.querySelector(".nav-more button");
    moreButton.addEventListener("click", () => {
      const expanded = moreButton.getAttribute("aria-expanded") === "true";
      moreButton.setAttribute("aria-expanded", String(!expanded));
      header.querySelector(".nav-dropdown").classList.toggle("show", !expanded);
    });
    document.addEventListener("click", (event) => {
      if (!header.contains(event.target)) {
        mobileMenu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.innerHTML = '<i class="bi bi-list"></i>';
        header.querySelector(".nav-dropdown").classList.remove("show");
        moreButton.setAttribute("aria-expanded", "false");
      }
    });
  }

  function renderFooter() {
    footer.innerHTML = `<footer class="site-footer"><div class="container"><div class="footer-main">
      <div class="footer-brand"><a class="brand" href="index.html"><span class="brand-mark">N</span>nutri<span class="brand-dot">lens</span></a><p>A friendlier way to discover better-for-you snacks. Tiny choices, feel-good momentum.</p></div>
      <div class="footer-col"><strong>Discover</strong><a href="explore.html">Explore snacks</a><a href="nutrition.html?id=potato-chips">Nutrition details</a><a href="compare.html">Smart snack swap</a><a href="scanner.html">Barcode demo</a></div>
      <div class="footer-col"><strong>Your journey</strong><a href="dashboard.html">Dashboard</a><a href="progress.html">My snack swaps</a><a href="challenges.html">Weekly challenge</a></div>
      <div class="footer-col"><strong>Good ideas</strong><a href="hostel-hacks.html">Hostel snack hacks</a><a href="sugar.html">Sugar visualizer</a><a href="#site-header">Back to top ↑</a></div>
    </div><div class="footer-bottom"><span>© ${new Date().getFullYear()} NutriLens. Made for everyday snackers.</span><span class="demo-disclaimer">Demo project · Sample nutrition values are illustrative, not verified product labels.</span></div></div></footer>`;
  }

  function initializeHome() {
    const root = document.getElementById("popular-snacks");
    if (!root) return;
    const picks = ["roasted-makhana", "roasted-chana", "protein-yogurt", "air-popped-popcorn"]
      .map((id) => window.NUTRILENS_SNACKS.find((snack) => snack.id === id))
      .filter(Boolean);
    root.innerHTML = picks.map((snack) => `<a class="popular-card" href="nutrition.html?id=${encodeURIComponent(snack.id)}">
      <img src="${snack.image}" alt="${snack.name}" loading="lazy"><div class="popular-card-body"><h3>${snack.name}</h3><p>${snack.origin}</p><div class="popular-meta"><span>${snack.perServing.calories} kcal / serve</span><span class="grade-chip grade-${snack.grade}">${snack.grade}</span></div></div></a>`).join("");
    initializeCounters();
  }

  function initializeCounters() {
    document.querySelectorAll("[data-count]").forEach((element) => {
      const target = Number(element.dataset.count);
      if (!target) return;
      const start = performance.now();
      const duration = 950;
      function tick(now) {
        const progress = Math.min(1, (now - start) / duration);
        element.textContent = Math.round(target * (1 - Math.pow(1 - progress, 3))).toLocaleString();
        if (progress < 1) requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
  }

  function initializeDashboard() {
    const statsRoot = document.getElementById("dashboard-stats");
    if (!statsRoot || !window.NutriLensTracker) return;
    const stats = NutriLensTracker.getStats();
    statsRoot.innerHTML = statCards(stats);
    const challenge = NutriLensTracker.getChallengeState();
    const count = document.getElementById("challenge-count");
    const bar = document.getElementById("challenge-bar");
    if (count) count.textContent = `${challenge.completedThisWeek} / 7`;
    if (bar) bar.style.width = `${challenge.completedThisWeek / 7 * 100}%`;
    renderHistory(document.getElementById("recent-swaps"), NutriLensTracker.readSwaps().slice(0, 4));
    const recRoot = document.getElementById("dashboard-recommendations");
    if (recRoot) {
      const recommendations = window.NUTRILENS_SNACKS.filter((snack) => snack.healthy).slice(0, 4);
      recRoot.innerHTML = recommendations.map((snack) => `<div class="recommendation-item"><img src="${snack.image}" alt="" loading="lazy"><div><strong>${snack.name}</strong><small>${snack.perServing.calories} kcal · Grade ${snack.grade}</small></div><a href="nutrition.html?id=${encodeURIComponent(snack.id)}" aria-label="View ${snack.name}"><i class="bi bi-arrow-up-right"></i></a></div>`).join("");
    }
    drawWeeklyChart("weekly-chart", challenge.days);
  }

  function statCards(stats) {
    return [
      ["Calories saved", stats.calories.toLocaleString(), "kcal", "bi-lightning-charge", "One smart swap at a time"],
      ["Sugar saved", formatStat(stats.sugar), "g", "bi-droplet", "Small changes count"],
      ["Sodium saved", stats.sodium.toLocaleString(), "mg", "bi-heart-pulse", "A little less, each time"],
      ["Successful swaps", stats.swaps.toLocaleString(), "", "bi-arrow-repeat", "Your feel-good moments"]
    ].map(([label, value, unit, icon, sub]) => `<article class="stat-card"><div class="stat-top"><span>${label}</span><span class="stat-icon"><i class="bi ${icon}"></i></span></div><div class="stat-value">${value}<small>${unit ? ` ${unit}` : ""}</small></div><div class="stat-sub">${sub}</div></article>`).join("");
  }

  function formatStat(value) {
    return Number.isInteger(value) ? String(value) : Number(value.toFixed(1)).toString();
  }

  function renderHistory(root, swaps) {
    if (!root) return;
    if (!swaps.length) {
      root.innerHTML = `<div class="history-empty"><i class="bi bi-arrow-left-right"></i><strong>Your first swap is waiting.</strong><p>Compare a snack and log a feel-good switch to see it here.</p><a class="text-link" href="explore.html">Explore snacks <i class="bi bi-arrow-right"></i></a></div>`;
      return;
    }
    root.innerHTML = swaps.map((swap) => {
      const from = window.NUTRILENS_SNACKS.find((snack) => snack.id === swap.fromId);
      const to = window.NUTRILENS_SNACKS.find((snack) => snack.id === swap.toId);
      if (!from || !to) return "";
      return `<a class="swap-row" href="compare.html?from=${encodeURIComponent(from.id)}&to=${encodeURIComponent(to.id)}"><img class="swap-thumb" src="${to.image}" alt=""><span class="swap-row-main"><strong>${from.name} <i class="bi bi-arrow-right"></i> ${to.name}</strong><small>${formatDate(swap.date)}</small></span><span class="swap-row-saving"><strong>−${swap.caloriesSaved} kcal</strong><small>saved per serving</small></span></a>`;
    }).join("");
  }

  function formatDate(dateString) {
    return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date(dateString));
  }

  function drawWeeklyChart(canvasId, days) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !window.Chart) return;
    new Chart(canvas, {
      type: "bar",
      data: {
        labels: days.map((item) => new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(item.date)),
        datasets: [{ data: days.map((item) => item.count), backgroundColor: days.map((item) => item.count ? "#762F45" : "#EDE5DF"), borderRadius: 7, borderSkipped: false, maxBarThickness: 30 }]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: (context) => `${context.raw} ${context.raw === 1 ? "swap" : "swaps"}` } } },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { color: "#B9A49A", font: { size: 10 } } },
          y: { beginAtZero: true, suggestedMax: 3, ticks: { stepSize: 1, color: "#B9A49A", font: { size: 9 }, precision: 0 }, grid: { color: "#F7F3EF" }, border: { display: false } }
        }
      }
    });
  }

  function initializeProgress() {
    const statsRoot = document.getElementById("progress-stats");
    if (!statsRoot || !window.NutriLensTracker) return;
    statsRoot.innerHTML = statCards(NutriLensTracker.getStats());
    const swaps = NutriLensTracker.readSwaps();
    renderHistory(document.getElementById("all-swaps"), swaps);
    drawWeeklyChart("progress-chart", NutriLensTracker.getWeeklyDays());
    renderBadges(swaps);
    const exportButton = document.getElementById("export-history");
    if (exportButton) exportButton.addEventListener("click", exportHistory);
  }

  function renderBadges(swaps) {
    const root = document.getElementById("achievement-badges");
    if (!root) return;
    const calories = swaps.reduce((sum, item) => sum + item.caloriesSaved, 0);
    const badges = [
      ["First feel-good swap", "Log your first snack swap.", "bi-stars", swaps.length >= 1],
      ["A week of wins", "Make 7 successful snack swaps.", "bi-calendar-heart", swaps.length >= 7],
      ["The 500 club", "Save 500 calories through swaps.", "bi-lightning", calories >= 500],
      ["Swap streak", "Keep making choices that feel good.", "bi-fire", NutriLensTracker.getChallengeState().streak >= 3]
    ];
    root.innerHTML = `<div class="badge-list">${badges.map(([title, detail, icon, earned]) => `<div class="badge-item ${earned ? "earned" : ""}"><span class="badge-icon"><i class="bi ${icon}"></i></span><span><strong>${title}</strong><small>${earned ? "Unlocked — nice work!" : detail}</small></span></div>`).join("")}</div>`;
  }

  function exportHistory() {
    const swaps = NutriLensTracker.readSwaps();
    const rows = [["Date", "Original snack", "Swapped to", "Calories saved", "Sugar saved (g)", "Sodium saved (mg)"]];
    swaps.forEach((swap) => {
      const from = window.NUTRILENS_SNACKS.find((snack) => snack.id === swap.fromId);
      const to = window.NUTRILENS_SNACKS.find((snack) => snack.id === swap.toId);
      rows.push([formatDate(swap.date), from ? from.name : swap.fromId, to ? to.name : swap.toId, swap.caloriesSaved, swap.sugarSaved, swap.sodiumSaved]);
    });
    const csv = rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "nutrilens-swap-history.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  function initializeChallenges() {
    if (window.NutriLensChallenges) window.NutriLensChallenges.initializePage();
  }

  function initializeHostelHacks() {
    const root = document.getElementById("hostel-hacks-grid");
    if (!root) return;
    root.innerHTML = window.NUTRILENS_HACKS.map((hack) => {
      const imageNotice = hack.image.includes("photo-not-verified")
        ? '<span class="image-verification-note">Photo not verified</span>'
        : "";
      return `<article class="hack-card">${imageNotice}<img src="${hack.image}" alt="${hack.image.includes("photo-not-verified") ? `No verified photo available for ${hack.title}` : hack.title}" loading="lazy"><div class="hack-card-body"><h3>${hack.title}</h3><p>${hack.benefit}</p><div class="hack-meta"><span><i class="bi bi-clock"></i> ${hack.time}</span><span><i class="bi bi-currency-rupee"></i> ${hack.cost}</span></div><div class="hack-ingredients"><strong>You'll need</strong><p>${hack.ingredients}</p></div></div></article>`;
    }).join("");
  }

  function initializeSugar() {
    const select = document.getElementById("sugar-drink");
    if (!select) return;
    const data = window.NUTRILENS_SUGAR_DRINKS;
    function render() {
      const drink = data[select.value];
      const cubes = Math.floor(drink.sugar / 4);
      const remainder = drink.sugar % 4;
      document.getElementById("sugar-grams").textContent = `${drink.sugar}g`;
      document.getElementById("sugar-drink-card").innerHTML = `<span class="drink-emoji">${drink.emoji}</span><span><strong>${drink.name}</strong><small>${drink.volume} · ${drink.note}</small></span>`;
      const cubeRoot = document.getElementById("sugar-cubes");
      cubeRoot.innerHTML = Array.from({ length: cubes }, () => '<span class="sugar-cube" title="4g sugar"></span>').join("");
      if (remainder) cubeRoot.insertAdjacentHTML("beforeend", `<span class="sugar-cube partial-cube" style="--cube-fill:${remainder / 4 * 100}%" title="${remainder}g sugar"></span>`);
      if (!drink.sugar) cubeRoot.innerHTML = '<span class="zero-sugar">No sugar cubes in this serving</span>';
      document.getElementById("sugar-comparison").innerHTML = drink.sugar
        ? `<strong>${cubes} full cube${cubes === 1 ? "" : "s"}${remainder ? ` + ${remainder}g` : ""}</strong> · roughly ${drink.sugar / 4} sugar-cube equivalents`
        : "A zero-sugar choice in this illustrative comparison.";
    }
    select.addEventListener("change", render);
    render();
  }

  function initializeScanner() {
    const input = document.getElementById("barcode-input");
    if (!input) return;
    const result = document.getElementById("barcode-result");
    const error = document.getElementById("scanner-error");
    function lookup(value) {
      const code = value.trim();
      if (!/^\d{8,14}$/.test(code)) {
        error.textContent = "Enter an 8–14 digit barcode number, or choose one of the demo examples.";
        result.innerHTML = "";
        input.focus();
        return;
      }
      const snackId = window.NUTRILENS_BARCODES[code];
      const snack = window.NUTRILENS_SNACKS.find((item) => item.id === snackId);
      if (!snack) {
        error.textContent = "This code isn't in the local demo catalog. No live product lookup is connected.";
        result.innerHTML = "";
        return;
      }
      error.textContent = "";
      result.innerHTML = `<article class="barcode-result-card"><img src="${snack.image}" alt="${snack.name}"><div><strong>${snack.name} · Grade ${snack.grade}</strong><small>${snack.perServing.calories} kcal per ${snack.servingSize}${snack.servingUnit} · Sample catalog match</small></div><a class="btn btn-forest" href="nutrition.html?id=${encodeURIComponent(snack.id)}">View nutrition</a></article>`;
      result.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
    document.getElementById("barcode-submit").addEventListener("click", () => lookup(input.value));
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") lookup(input.value);
    });
    document.querySelectorAll(".demo-barcode").forEach((button) => button.addEventListener("click", () => {
      input.value = button.dataset.code;
      lookup(input.value);
    }));
  }
})();

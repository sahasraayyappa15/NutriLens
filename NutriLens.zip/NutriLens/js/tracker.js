// Small LocalStorage helpers shared by the dashboard, swaps, and challenge pages.
(() => {
  const SWAPS_KEY = "nutrilens-swaps-v1";
  const CHALLENGE_KEY = "nutrilens-challenge-v1";

  function readSwaps() {
    const saved = localStorage.getItem(SWAPS_KEY);
    return saved ? JSON.parse(saved) : [];
  }

  function saveSwap(original, alternative) {
    const entry = {
      id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
      fromId: original.id,
      toId: alternative.id,
      date: new Date().toISOString(),
      day: localDateKey(new Date()),
      caloriesSaved: Math.max(0, original.perServing.calories - alternative.perServing.calories),
      sugarSaved: Math.max(0, original.perServing.sugar - alternative.perServing.sugar),
      sodiumSaved: Math.max(0, original.perServing.sodium - alternative.perServing.sodium),
      saturatedFatSaved: Math.max(0, original.perServing.saturatedFat - alternative.perServing.saturatedFat),
      proteinGained: Math.max(0, alternative.perServing.protein - original.perServing.protein),
      fiberGained: Math.max(0, alternative.perServing.fiber - original.perServing.fiber)
    };
    const swaps = readSwaps();
    swaps.unshift(entry);
    localStorage.setItem(SWAPS_KEY, JSON.stringify(swaps));
    return entry;
  }

  function localDateKey(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }

  function getWeeklyDays() {
    const today = new Date();
    const start = new Date(today);
    start.setDate(today.getDate() - 6);
    const swaps = readSwaps();
    return Array.from({ length: 7 }, (_, index) => {
      const date = new Date(start);
      date.setDate(start.getDate() + index);
      const key = localDateKey(date);
      return {
        key,
        date,
        count: swaps.filter((swap) => swap.day === key).length,
        complete: swaps.some((swap) => swap.day === key)
      };
    });
  }

  function getStats() {
    const swaps = readSwaps();
    return swaps.reduce((total, swap) => ({
      swaps: total.swaps + 1,
      calories: total.calories + swap.caloriesSaved,
      sugar: total.sugar + swap.sugarSaved,
      sodium: total.sodium + swap.sodiumSaved
    }), { swaps: 0, calories: 0, sugar: 0, sodium: 0 });
  }

  function getChallengeState() {
    const stored = JSON.parse(localStorage.getItem(CHALLENGE_KEY) || "{}");
    const days = getWeeklyDays();
    const swaps = readSwaps();
    const completedDates = new Set(days.filter((day) => day.complete).map((day) => day.key));
    Object.keys(stored.completed || {}).forEach((date) => {
      if (stored.completed[date]) completedDates.add(date);
    });
    const completedThisWeek = days.filter((day) => completedDates.has(day.key)).length;
    let streak = 0;
    const cursor = new Date();
    if (!completedDates.has(localDateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
    while (completedDates.has(localDateKey(cursor))) {
      streak += 1;
      cursor.setDate(cursor.getDate() - 1);
    }
    return { days, completedDates, completedThisWeek, streak, swaps };
  }

  function markChallengeDay(dateKey) {
    const stored = JSON.parse(localStorage.getItem(CHALLENGE_KEY) || "{}");
    stored.completed = stored.completed || {};
    stored.completed[dateKey] = !stored.completed[dateKey];
    localStorage.setItem(CHALLENGE_KEY, JSON.stringify(stored));
    return getChallengeState();
  }

  window.NutriLensTracker = { readSwaps, saveSwap, getStats, getWeeklyDays, getChallengeState, markChallengeDay, localDateKey };
})();

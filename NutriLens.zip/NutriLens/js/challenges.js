// Weekly challenge calendar, streak, and progress indicators.
(() => {
  function initializePage() {
    const calendar = document.getElementById("challenge-calendar");
    if (!calendar || !window.NutriLensTracker) return;

    const state = window.NutriLensTracker.getChallengeState();
    const days = state.days;
    const dateFormat = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" });
    const range = document.getElementById("week-range");
    if (range) range.textContent = `${dateFormat.format(days[0].date)} – ${dateFormat.format(days[6].date)}`;

    const todayKey = window.NutriLensTracker.localDateKey(new Date());
    calendar.innerHTML = days.map((item) => {
      const complete = state.completedDates.has(item.key);
      const today = item.key === todayKey;
      const weekday = new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(item.date);
      return `<button type="button" class="challenge-day ${complete ? "complete" : ""} ${today ? "today" : ""}" data-day="${item.key}" aria-pressed="${complete}"><span class="day-label">${weekday}${today ? " · Today" : ""}</span><strong class="day-date">${item.date.getDate()}</strong><span class="day-icon"><i class="bi ${complete ? "bi-check-lg" : "bi-plus-lg"}"></i></span><span class="day-state">${complete ? "A win logged" : "Tap to mark"}</span></button>`;
    }).join("");

    calendar.querySelectorAll("[data-day]").forEach((button) => button.addEventListener("click", () => {
      window.NutriLensTracker.markChallengeDay(button.dataset.day);
      initializePage();
    }));

    const count = state.completedThisWeek;
    const streak = document.getElementById("challenge-streak");
    if (streak) streak.textContent = state.streak;
    const label = document.getElementById("weekly-progress-label");
    if (label) label.textContent = `${count} of 7 days`;
    const bar = document.getElementById("weekly-progress-bar");
    if (bar) bar.style.width = `${count / 7 * 100}%`;
    const achievement = document.getElementById("challenge-achievement");
    if (achievement) achievement.innerHTML = count >= 7
      ? '<span class="challenge-achievement"><i class="bi bi-stars"></i> Challenge complete — you made room for seven good choices!</span>'
      : '<span class="challenge-achievement"><i class="bi bi-stars"></i> Every day you show up counts. Keep going.</span>';
  }

  window.NutriLensChallenges = { initializePage };
})();

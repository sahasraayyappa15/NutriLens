(() => {
  const grid = document.getElementById("snack-grid");
  if (!grid) return;

  const search = document.getElementById("snack-search");
  const filters = document.getElementById("category-filters");
  const sort = document.getElementById("snack-sort");
  const resultsCount = document.getElementById("results-count");
  const emptyResults = document.getElementById("empty-results");
  const allSnacks = window.NUTRILENS_SNACKS || [];
  let activeCategory = "all";
  document.getElementById("all-count").textContent = allSnacks.length;

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[char]));
  }

  function renderSnack(snack) {
    const imageAlt = snack.image.includes("photo-not-verified")
      ? `No verified photo available for ${snack.name}`
      : snack.name;
    const imageNotice = snack.image.includes("photo-not-verified")
      ? '<span class="image-verification-note">Photo not verified</span>'
      : "";
    return `<article class="snack-card">
      <div class="snack-card-img"><img src="${snack.image}" alt="${escapeHtml(imageAlt)}" loading="lazy">${imageNotice}<span class="snack-grade"><span class="grade-chip grade-${snack.grade}">${snack.grade}</span> NutriLens grade</span></div>
      <div class="snack-card-body"><div class="snack-card-title"><h3>${escapeHtml(snack.name)}</h3><span class="grade-chip grade-${snack.grade}">${snack.grade}</span></div>
      <div class="snack-origin">${escapeHtml(snack.origin)}</div><div class="snack-card-stats"><strong>${snack.perServing.calories}</strong><span>kcal / serve</span><i class="stat-divider"></i><span>${snack.perServing.protein}g protein</span></div>
      <div class="snack-card-actions"><a class="snack-details-link" href="nutrition.html?id=${encodeURIComponent(snack.id)}"><i class="bi bi-info-circle"></i> Details</a><a class="snack-compare-link" href="compare.html?from=${encodeURIComponent(snack.id)}"><i class="bi bi-arrow-left-right"></i> Compare</a></div></div></article>`;
  }

  function render() {
    const term = search.value.trim().toLowerCase();
    let items = allSnacks.filter((snack) => {
      const matchesTerm = !term || `${snack.name} ${snack.category} ${snack.origin}`.toLowerCase().includes(term);
      const matchesCategory = activeCategory === "all" ||
        (activeCategory === "healthy" ? snack.healthy :
          activeCategory === "junk" ? !snack.healthy : snack.category === activeCategory);
      return matchesTerm && matchesCategory;
    });
    if (sort.value === "calories") items.sort((a, b) => a.perServing.calories - b.perServing.calories);
    if (sort.value === "grade") items.sort((a, b) => a.grade.localeCompare(b.grade));
    if (sort.value === "popular") items.sort((a, b) => Number(b.id === "potato-chips") - Number(a.id === "potato-chips"));
    grid.innerHTML = items.map(renderSnack).join("");
    resultsCount.textContent = `${items.length} ${items.length === 1 ? "snack" : "snacks"} to explore`;
    emptyResults.classList.toggle("d-none", items.length > 0);
    grid.classList.toggle("d-none", items.length === 0);
  }

  search.addEventListener("input", render);
  sort.addEventListener("change", render);
  filters.addEventListener("click", (event) => {
    const button = event.target.closest("[data-category]");
    if (!button) return;
    activeCategory = button.dataset.category;
    filters.querySelectorAll(".filter-pill").forEach((pill) => pill.classList.toggle("active", pill === button));
    render();
  });
  document.getElementById("clear-filters").addEventListener("click", () => {
    search.value = "";
    activeCategory = "all";
    sort.value = "popular";
    filters.querySelectorAll(".filter-pill").forEach((pill) => pill.classList.toggle("active", pill.dataset.category === "all"));
    render();
    search.focus();
  });
  render();
})();

(() => {
  const root = document.getElementById("nutrition-detail");
  if (!root) return;
  const snacks = window.NUTRILENS_SNACKS || [];
  const id = new URLSearchParams(location.search).get("id") || "potato-chips";
  const snack = snacks.find((item) => item.id === id) || snacks.find((item) => item.id === "potato-chips");
  const alternatives = window.NutriLensRecommendations.recommendSnacks(snack.id, 3);
  let unit = "perServing";

  const nutrients = [
    ["Calories", "calories", "kcal"], ["Total fat", "totalFat", "g"],
    ["Saturated fat", "saturatedFat", "g"], ["Carbohydrates", "carbohydrates", "g"],
    ["Sugar", "sugar", "g"], ["Protein", "protein", "g"],
    ["Fibre", "fiber", "g"], ["Sodium", "sodium", "mg"]
  ];

  function showValue(value, key) {
    return key === "calories" || key === "sodium" ? Math.round(value) : Number(value.toFixed(1));
  }

  function render() {
    const factSet = snack[unit];
    const imageUnverified = snack.image.includes("photo-not-verified");
    const imageAlt = imageUnverified ? `No verified photo available for ${snack.name}` : snack.name;
    root.innerHTML = `<a class="back-link" href="explore.html"><i class="bi bi-arrow-left"></i> Back to the snack shelf</a>
      <div class="nutrition-layout"><div><div class="nutrition-photo"><img src="${snack.image}" alt="${imageAlt}">${imageUnverified ? '<span class="image-verification-note">Photo not verified</span>' : ""}<span class="snack-grade"><span class="grade-chip grade-${snack.grade}">${snack.grade}</span> NutriLens grade</span><div class="nutrition-photo-caption"><h2>${snack.name}</h2><p>${snack.origin}</p></div></div>
      <div class="alternatives-mini"><h3>Good things to try instead</h3>${alternatives.map((item) => `<div class="mini-alternative"><img src="${item.image}" alt="" loading="lazy"><div><strong>${item.name}</strong><small>${item.perServing.calories} kcal · Grade ${item.grade}</small></div><a class="btn btn-outline-forest" href="compare.html?from=${encodeURIComponent(snack.id)}&to=${encodeURIComponent(item.id)}">Compare</a></div>`).join("")}</div></div>
      <section class="panel nutrition-detail-panel"><div class="nutrition-header"><div><span class="eyebrow eyebrow-dark">THE NUTRITION STORY</span><h1>${snack.name}</h1><p>${snack.servingSize} ${snack.servingUnit} serving · Illustrative demo data</p></div><span class="grade-chip grade-${snack.grade}">${snack.grade}</span></div>
      <div class="grade-summary"><span class="grade-chip grade-${snack.grade}">${snack.grade}</span><div><strong>${gradeTitle(snack.grade)} choice</strong><small>${gradeExplanation(snack.grade)}</small></div></div>
      <div class="traffic-light"><span class="${snack.grade === "A" || snack.grade === "B" ? "light-on" : ""}"></span><span class="${snack.grade === "C" ? "light-on" : ""}"></span><span class="${snack.grade === "D" || snack.grade === "E" ? "light-on" : ""}"></span><small>At-a-glance balance</small></div>
      <div class="serving-tabs"><button type="button" class="${unit === "perServing" ? "active" : ""}" data-unit="perServing">Per serving</button><button type="button" class="${unit === "per100" ? "active" : ""}" data-unit="per100">Per 100${snack.servingUnit}</button></div>
      <div class="nutrition-list">${nutrients.map(([label, key, suffix]) => `<div class="nutrition-row"><span>${label}</span><strong>${showValue(factSet[key], key)} ${suffix}</strong></div>`).join("")}</div>
      <div class="nutrition-explain"><i class="bi bi-lightbulb-fill"></i>${snack.description} Grades are a simple demo guide based on the sample profile—not medical advice or a verified product rating.</div>
      <div class="nutrition-cta-row"><a href="compare.html?from=${encodeURIComponent(snack.id)}&to=${encodeURIComponent(alternatives[0] ? alternatives[0].id : "")}" class="btn btn-forest"><i class="bi bi-arrow-left-right"></i> Compare a smarter swap</a><a href="explore.html" class="btn btn-outline-forest">Explore more</a></div></section></div>`;
    root.querySelectorAll("[data-unit]").forEach((button) => button.addEventListener("click", () => {
      unit = button.dataset.unit;
      render();
    }));
  }

  function gradeTitle(grade) {
    return ({ A: "Great", B: "Balanced", C: "Everyday", D: "Occasional", E: "Treat" })[grade];
  }

  function gradeExplanation(grade) {
    return ({ A: "A nutrient-dense pick for your snack rotation.", B: "A balanced option to enjoy as part of your day.", C: "A middle-of-the-road choice; compare portions.", D: "A tasty pick to enjoy now and then.", E: "A fun treat—try comparing a lighter alternative." })[grade];
  }

  render();
})();

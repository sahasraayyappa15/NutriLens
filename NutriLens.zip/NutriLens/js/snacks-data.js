// Illustrative sample data for the NutriLens demo; it is not verified product labeling.
(() => {
  const image = (name) => `assets/images/${name}.jpg`;
  const photos = {
    chips: image("potato-chips"),
    bananaChips: image("banana-chips"),
    makhana: image("roasted-makhana"),
    chickpeas: image("roasted-chickpeas"),
    samosa: image("samosa"),
    noodles: image("instant-noodles"),
    popcorn: image("popcorn"),
    chocolate: image("chocolate"),
    cookies: image("biscuits"),
    nuts: image("mixed-nuts"),
    fruit: image("fresh-fruit"),
    banana: image("banana"),
    dates: image("dates"),
    sweetPotato: image("sweet-potato"),
    applePeanutButter: image("apple-peanut-butter"),
    energyBites: image("energy-bites"),
    ladoo: image("ladoo"),
    strawberries: image("strawberries"),
    yogurt: image("yogurt-berries"),
    cola: image("cola"),
    peanuts: image("masala-peanuts"),
    cheesePuffs: image("cheese-puffs"),
    icedTea: image("iced-tea"),
    orangeJuice: image("orange-juice"),
    coconutWater: image("coconut-water"),
    sparklingWater: image("sparkling-water"),
    lassi: image("lassi"),
    energyDrink: image("energy-drink"),
    hummus: image("hummus-pita"),
    snack: image("healthy-snack-bowl"),
    pretzels: image("pretzels"),
    saltedPretzels: image("salted-pretzels"),
    riceCrackers: image("rice-crackers"),
    tortillaChips: image("tortilla-chips"),
    edamame: image("edamame"),
    samosa: image("samosa"),
    noodles: image("instant-noodles"),
    sandwich: "assets/images/photo-not-verified.svg",
    dessert: image("ladoo"),
    meal: image("sweet-potato"),
    unavailable: "assets/images/photo-not-verified.svg"
  };

  function makeSnack(id, name, category, grade, calories, sugar, protein, fiber, satFat, sodium, serving, photo, origin, healthy, carbs, fat) {
    const servingSize = serving || 30;
    const scale = 100 / servingSize;
    const servingFacts = {
      calories, totalFat: fat === undefined ? 8 : fat, saturatedFat: satFat,
      carbohydrates: carbs === undefined ? 18 : carbs,
      sugar, protein, fiber, sodium
    };
    const per100 = {};
    Object.keys(servingFacts).forEach((key) => {
      per100[key] = Math.round(servingFacts[key] * scale * 10) / 10;
    });
    return {
      id, name, category, grade, servingSize, servingUnit: category === "drinks" ? "ml" : "g",
      perServing: servingFacts, per100, image: photo, origin, healthy: Boolean(healthy),
      description: healthy
        ? "A satisfying everyday option with a little more goodness in every bite."
        : "A familiar favorite. Enjoy the flavor, and use the facts to explore your options."
    };
  }

  window.NUTRILENS_SNACKS = [
    makeSnack("potato-chips", "Potato Chips", "crunchy", "E", 160, 1, 2, 1, 3, 170, 30, photos.chips, "India · Classic", false, 15, 10),
    makeSnack("roasted-makhana", "Roasted Salted Makhana", "crunchy", "A", 70, 1, 6, 3, 0.9, 110, 30, photos.makhana, "India · Roasted", true, 12, 1.5),
    makeSnack("masala-makhana", "Masala Makhana", "crunchy", "A", 85, 1, 5, 3, 0.8, 130, 30, photos.makhana, "India · Spiced", true, 14, 2),
    makeSnack("banana-chips", "Banana Chips", "crunchy", "D", 155, 6, 1, 2, 5, 85, 30, photos.bananaChips, "India · Sweet & crisp", false, 17, 9),
    makeSnack("mixture", "Kara Sev Mixture", "crunchy", "E", 170, 2, 4, 2, 3.5, 290, 30, photos.unavailable, "India · Photo not verified", false, 17, 10),
    makeSnack("namkeen", "Aloo Bhujia", "crunchy", "E", 165, 1, 4, 2, 3, 310, 30, photos.unavailable, "India · Photo not verified", false, 16, 10),
    makeSnack("khakhra", "Whole Wheat Khakhra", "crunchy", "B", 112, 1, 3, 3, 0.7, 190, 30, photos.unavailable, "India · Photo not verified", true, 20, 2),
    makeSnack("roasted-chana", "Roasted Chickpeas", "crunchy", "A", 115, 1, 6, 5, 0.3, 95, 30, photos.chickpeas, "India · Protein-rich", true, 18, 2),
    makeSnack("masala-peanuts", "Masala Peanuts", "crunchy", "C", 175, 2, 7, 3, 2.5, 180, 30, photos.peanuts, "India · Spiced", false, 6, 14),
    makeSnack("cheese-puffs", "Cheese Puffs", "crunchy", "E", 160, 1, 2, 1, 3, 270, 30, photos.cheesePuffs, "International · Cheese puffs", false, 16, 10),
    makeSnack("tortilla-chips", "Tortilla Chips", "crunchy", "D", 150, 1, 2, 2, 1.5, 125, 30, photos.tortillaChips, "International · Corn", false, 19, 7),
    makeSnack("salted-pretzels", "Salted Pretzels", "crunchy", "D", 115, 1, 3, 1, 0.3, 350, 30, photos.saltedPretzels, "International · Baked", false, 23, 1),
    makeSnack("popcorn", "Movie-Style Popcorn", "crunchy", "C", 150, 1, 3, 3, 2, 280, 30, photos.popcorn, "International · Salty", false, 17, 8),
    makeSnack("air-popped-popcorn", "Air-popped Popcorn", "crunchy", "A", 93, 0.2, 3, 3.5, 0.2, 2, 30, photos.popcorn, "International · Plain", true, 18, 1),
    makeSnack("trail-mix", "Fruit & Nut Trail Mix", "crunchy", "B", 145, 8, 4, 2, 1, 25, 30, photos.nuts, "International · Mix", true, 14, 9),
    makeSnack("rice-crackers", "Rice Crackers", "crunchy", "C", 128, 1, 2, 0.5, 0.4, 210, 30, photos.riceCrackers, "International · Light", false, 27, 1),
    makeSnack("roasted-soy", "Roasted Soy Nuts", "crunchy", "A", 130, 1, 12, 5, 0.8, 75, 30, photos.unavailable, "International · Photo not verified", true, 10, 6),
    makeSnack("pita-hummus", "Pita & Hummus", "crunchy", "B", 165, 2, 5, 3, 1, 240, 60, photos.hummus, "Mediterranean · Savory", true, 25, 5),
    makeSnack("seaweed-crisps", "Seaweed Crisps", "crunchy", "B", 80, 0, 2, 1, 0.2, 120, 15, photos.unavailable, "International · Photo not verified", true, 5, 6),
    makeSnack("roasted-edamame", "Roasted Edamame", "crunchy", "A", 130, 1, 13, 5, 0.7, 120, 30, photos.edamame, "International · Protein-rich", true, 9, 6),

    makeSnack("milk-chocolate", "Milk Chocolate", "sweet", "D", 165, 18, 2, 1, 3.5, 35, 30, photos.chocolate, "International · Chocolate", false, 18, 10),
    makeSnack("cream-cookies", "Cream Sandwich Cookies", "sweet", "E", 145, 11, 1, 0.5, 3, 75, 30, photos.cookies, "International · Sweet", false, 22, 6),
    makeSnack("granola-bar", "Chocolate Granola Bar", "sweet", "C", 135, 8, 3, 2, 1.5, 95, 35, photos.unavailable, "International · Photo not verified", false, 22, 5),
    makeSnack("dark-chocolate", "Dark Chocolate (70%)", "sweet", "B", 170, 7, 2, 3, 5, 5, 30, photos.chocolate, "International · Rich", true, 13, 12),
    makeSnack("dates", "Dates & Almonds", "sweet", "A", 130, 13, 3, 3, 0.4, 5, 30, photos.dates, "Middle East · Naturally sweet", true, 20, 5),
    makeSnack("fruit-yogurt", "Fruit Yogurt Cup", "sweet", "C", 145, 16, 5, 0, 2, 65, 150, photos.yogurt, "International · Chilled", false, 24, 4),
    makeSnack("apple-peanut-butter", "Apple & Peanut Butter", "sweet", "A", 155, 12, 4, 4, 1.5, 75, 100, photos.applePeanutButter, "Everyday · Fresh", true, 20, 8),
    makeSnack("banana", "Fresh Banana", "sweet", "A", 89, 12, 1, 2.5, 0.1, 1, 100, photos.banana, "Everyday · Fresh", true, 23, 0.3),
    makeSnack("fruit-cup", "Seasonal Fruit Cup", "sweet", "A", 75, 12, 1, 2, 0, 5, 120, photos.strawberries, "Everyday · Fresh", true, 18, 0.3),
    makeSnack("protein-yogurt", "Greek Yogurt & Berries", "sweet", "A", 118, 8, 11, 2, 0.4, 45, 150, photos.yogurt, "Everyday · Protein-rich", true, 14, 2),
    makeSnack("peanut-chikki", "Peanut Chikki", "sweet", "C", 150, 12, 4, 2, 1, 35, 30, photos.unavailable, "India · Photo not verified", false, 17, 8),
    makeSnack("til-ladoo", "Sesame Jaggery Ladoo", "sweet", "C", 145, 11, 3, 2, 1, 15, 30, photos.ladoo, "India · Traditional", false, 16, 8),
    makeSnack("roasted-sweet-potato", "Roasted Sweet Potato", "sweet", "A", 90, 6, 2, 3, 0.1, 55, 100, photos.meal, "Everyday · Comforting", true, 21, 0.2),
    makeSnack("oat-energy-bites", "Oat & Date Energy Bites", "sweet", "B", 125, 9, 3, 3, 1, 30, 35, photos.energyBites, "Homemade · No-bake", true, 19, 4),
    makeSnack("strawberries", "Fresh Strawberries", "sweet", "A", 50, 7, 1, 2, 0, 1, 150, photos.strawberries, "Everyday · Fresh", true, 12, 0.5),

    makeSnack("cola", "Cola", "drinks", "E", 139, 39, 0, 0, 0, 15, 330, photos.cola, "International · Fizzy", false, 39, 0),
    makeSnack("sweet-iced-tea", "Sweet Iced Tea", "drinks", "D", 105, 25, 0, 0, 0, 10, 330, photos.icedTea, "International · Chilled", false, 27, 0),
    makeSnack("orange-juice", "Orange Juice", "drinks", "B", 112, 21, 2, 0.5, 0, 2, 250, photos.orangeJuice, "Everyday · Fruit juice", true, 26, 0.5),
    makeSnack("coconut-water", "Coconut Water", "drinks", "A", 46, 9, 0.5, 0, 0, 105, 250, photos.coconutWater, "Everyday · Hydrating", true, 11, 0),
    makeSnack("sweet-lassi", "Sweet Lassi", "drinks", "C", 180, 20, 6, 0, 2, 85, 250, photos.lassi, "India · Chilled", false, 25, 6),
    makeSnack("unsweetened-lassi", "Unsweetened Lassi", "drinks", "A", 105, 8, 7, 0, 1.5, 90, 250, photos.lassi, "India · Chilled", true, 10, 4),
    makeSnack("energy-drink", "Energy Drink", "drinks", "E", 110, 27, 0, 0, 0, 190, 250, photos.energyDrink, "International · Caffeinated", false, 27, 0),
    makeSnack("sparkling-water", "Sparkling Water", "drinks", "A", 0, 0, 0, 0, 0, 0, 330, photos.sparklingWater, "Everyday · Unsweetened", true, 0, 0),
    makeSnack("samosa", "Samosa", "crunchy", "D", 262, 1.5, 5, 3, 4.5, 380, 100, photos.samosa, "India · Savory pastry", false, 32, 13),
    makeSnack("instant-noodles", "Instant Noodles", "crunchy", "E", 280, 2, 6, 2, 6, 900, 70, photos.noodles, "International · Quick meal", false, 42, 10),
    makeSnack("baked-soya-crisps", "Baked Soya Crisps", "crunchy", "B", 120, 1, 10, 4, 0.8, 150, 30, photos.unavailable, "Illustrative demo · Photo not verified", true, 14, 3)
  ];

  window.NUTRILENS_BARCODES = {
    "8901000000012": "potato-chips",
    "8901000000040": "roasted-makhana"
  };

  window.NUTRILENS_SUGAR_DRINKS = {
    cola: { name: "Cola", volume: "330 ml", sugar: 39, emoji: "🥤", note: "A familiar fizzy favorite" },
    "iced-tea": { name: "Sweet iced tea", volume: "330 ml", sugar: 25, emoji: "🧋", note: "Cool, sweet, and refreshing" },
    "orange-juice": { name: "Orange juice", volume: "250 ml", sugar: 21, emoji: "🍊", note: "Fruit juice sugars, naturally present" },
    "energy-drink": { name: "Energy drink", volume: "250 ml", sugar: 27, emoji: "⚡", note: "A sweet, caffeinated pick-me-up" },
    water: { name: "Sparkling water", volume: "330 ml", sugar: 0, emoji: "💧", note: "Bubbly and unsweetened" }
  };

  window.NUTRILENS_HACKS = [
    { title: "Desk-side chana crunch", image: photos.chickpeas, time: "2 min", cost: "₹20–30", ingredients: "Roasted chana, lemon, pinch of chaat masala", benefit: "Fibre + plant protein to help keep you satisfied." },
    { title: "Makhana masala bowl", image: photos.makhana, time: "5 min", cost: "₹25–35", ingredients: "Makhana, a little oil, pepper, turmeric, salt", benefit: "A light, crunchy swap with a little more protein." },
    { title: "Peanut butter banana toast", image: photos.sandwich, time: "5 min", cost: "₹30–45", ingredients: "Whole wheat bread, peanut butter, sliced banana", benefit: "A tasty mix of energy, fibre, and satisfying fats." },
    { title: "Curd & fruit cup", image: photos.yogurt, time: "3 min", cost: "₹25–40", ingredients: "Plain curd, seasonal fruit, a few nuts", benefit: "Protein and fruit in one cool, easy snack." },
    { title: "No-cook sprout chaat", image: photos.unavailable, time: "8 min", cost: "₹25–40", ingredients: "Ready sprouts, tomato, lemon, coriander", benefit: "A fresh, fibre-rich bowl with plant protein." },
    { title: "Microwave sweet potato", image: photos.sweetPotato, time: "8 min", cost: "₹20–35", ingredients: "One sweet potato, lemon, chilli powder", benefit: "Comforting fibre and naturally sweet flavour." }
  ];
})();
